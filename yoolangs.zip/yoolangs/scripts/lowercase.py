import os
import uuid

folder = '../src/languages'

for root, dirs, files in os.walk(folder):
    for filename in files:
        old_path = os.path.join(root, filename)
        new_filename = filename.lower()
        new_path = os.path.join(root, new_filename)

        if old_path != new_path:
            # Renomeia para nome temporário único
            temp_path = os.path.join(root, str(uuid.uuid4()))
            os.rename(old_path, temp_path)
            # Depois renomeia para o nome final minúsculo
            os.rename(temp_path, new_path)
            print(f'Renomeado: {old_path} -> {new_path}')