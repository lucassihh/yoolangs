#!/data/data/com.termux/files/usr/bin/bash

SRC_DIR="/storage/emulated/0/htdocs/yoolangs/src"
TERMUX_DIR="$HOME/yoolangs/src"
CSS_SRC="$TERMUX_DIR/css"
CSS_DEST="/storage/emulated/0/htdocs/yoolangs/src/css"

echo "==> Iniciando monitoramento de alterações em $SRC_DIR..."

while true; do
  inotifywait -e modify,create,delete,move -r "$SRC_DIR"

  echo "==> Mudança detectada. Sincronizando HTML..."
  rsync -av --delete --include='*/' --include='*.html' --exclude='*' "$SRC_DIR/" "$TERMUX_DIR/"

  echo "==> Rodando build do Tailwind..."
  cd "$HOME/yoolangs"
  npx tailwindcss -i "$CSS_SRC/input.css" -o "$CSS_SRC/output.css"

  echo "==> Copiando CSS de volta para Android (sobrescrevendo)..."
  cp -f "$CSS_SRC/output.css" "$CSS_DEST/output.css"

  echo "==> CSS copiado:"
  ls -l "$CSS_DEST/output.css"

  echo "==> Aguardando próxima modificação..."
done
