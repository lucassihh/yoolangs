

Cor principal da logo etc:  green-500

cor de titulos:  slate-700

textos: slate-600



