const cards = {
   Portuguese: {
      title: "Qual idioma você quer aprender?",
      options: [{
            name: "English",
            flag: "us.svg"
         },
         {
            name: "Spanish",
            flag: "es.svg"
         },
         {
            name: "Indonesian",
            flag: "id.svg"
         },
         {
            name: "Tagalog",
            flag: "ph.svg"
         },
      ],
   },
   Spanish: {
      title: "Qué idioma quieres aprender?",
      options: [{
            name: "English",
            flag: "us.svg"
         },
         {
            name: "Portuguese",
            flag: "br.svg"
         },
         {
            name: "Indonesian",
            flag: "id.svg"
         },
         {
            name: "Tagalog",
            flag: "ph.svg"
         },
      ],
   },
   English: {
      title: "Which language do you want to learn?",
      options: [{
            name: "Spanish",
            flag: "es.svg"
         },
         {
            name: "Portuguese",
            flag: "br.svg"
         },
         {
            name: "Indonesian",
            flag: "id.svg"
         },
         {
            name: "Tagalog",
            flag: "ph.svg"
         },
      ],
   },
   Indonesian: {
      title: "Bahasa apa yang ingin Anda pelajari?",
      options: [{
            name: "Spanish",
            flag: "es.svg"
         },
         {
            name: "Portuguese",
            flag: "br.svg"
         },
         {
            name: "English",
            flag: "us.svg"
         },
         {
            name: "Tagalog",
            flag: "ph.svg"
         },
      ],
   },
   Tagalog: {
      title: "Anong wika ang gusto mong matutunan?",
      options: [{
            name: "English",
            flag: "us.svg"
         },
         {
            name: "Portuguese",
            flag: "br.svg"
         },
         {
            name: "Spanish",
            flag: "es.svg"
         },
         {
            name: "Indonesian",
            flag: "id.svg"
         },
      ],
   },
};

function openModal(nativeLang) {
   const modal = document.getElementById('modal');
   const content = document.getElementById('modalContent');
   const modalTitle = document.getElementById('modalTitle');
   const container = document.getElementById('targetLanguageCards');

   modal.classList.remove('hidden');

   // Ativa animação com Tailwind
   requestAnimationFrame(() => {
      content.classList.remove('scale-95', 'opacity-20');
      content.classList.add('scale-100', 'opacity-100');
   });

   const native = cards[nativeLang];
   modalTitle.textContent = native?.title || `What do you want to learn using ${nativeLang}?`;
   container.innerHTML = '';

   (native?.options || []).forEach(lang => {
      container.innerHTML += `
      <a href="languages/${nativeLang.toLowerCase()}/learning-${lang.name.toLowerCase().replace(/ /g, '-')}/3_meeting_someone.html" class="group rounded-lg bg-white dark:bg-cinder border border-[0.5px] dark:border-gun hover:scale-105 p-4 h-fit transition">
        <div class="flex items-center justify-between gap-2">
          <div>
            <span class="text-lg font-bold tracking-wide text-gray-600 dark:text-white">${lang.name}</span>
              <div class="flex mt-2 space-x-2">
                 <span class="text-md font-medium text-gray-800 py-1 px-2 bg-gray-100 rounded-lg">Vocabulary</span>
                 <span class="text-md font-medium text-gray-800 py-1 px-2 bg-gray-100 rounded-lg">Quiz</span>
              </div>
           </div>
            <div>
              <img src="images/flag/${lang.flag}" alt="${lang.alt}" class="w-16 h-16 border-2 border-gray-200 rounded-lg object-cover"/>
            </div>
        </div>
      </a>
    `;
   });
}

document.getElementById('closeModal').addEventListener('click', () => {
   document.getElementById('modal').classList.add('hidden');

   const content = document.getElementById('modalContent');
   content.classList.remove('scale-100', 'opacity-100');
   content.classList.add('scale-95', 'opacity-0');
});