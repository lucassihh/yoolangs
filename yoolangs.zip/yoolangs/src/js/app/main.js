
         const languages = ["Portuguese", "Spanish", "English", "Indonesian", "Tagalog"];
         const nativeButton = document.getElementById("native-button");
         const learningButton = document.getElementById("learning-button");
         const nativeMenu = document.getElementById("native-menu");
         const learningMenu = document.getElementById("learning-menu");
         const nativeSelected = document.getElementById("native-selected");
         const learningSelected = document.getElementById("learning-selected");
         const nativeCaret = document.getElementById("native-caret");
         const learningCaret = document.getElementById("learning-caret");
         
         const nativeOptions = document.getElementById("native-options");
         const learningOptions = document.getElementById("learning-options");
         const startBtn = document.getElementById("startBtn");
         
         function activateLearningButton() {
           learningButton.classList.remove("pointer-events-none", "opacity-50");
         }
         
         function showStartIfReady() {
           const native = nativeSelected.textContent;
           const learning = learningSelected.textContent;
           const valid = languages.includes(native) && languages.includes(learning) && native !== learning;
           startBtn.classList.toggle("hidden", !valid);
         }
         
         function createOption(lang, target, selectedSpan, menu, button, caret, onSelect) {
           const a = document.createElement("a");
           a.href = "#";
           a.className = "block px-4 py-2 text-left text-md hover:bg-slate-600 focus:bg-slate-500";
           a.textContent = lang;
           a.setAttribute("role", "menuitem");
           a.addEventListener("click", (e) => {
             e.preventDefault();
             selectedSpan.textContent = lang;
             menu.classList.add("hidden");
             button.setAttribute("aria-expanded", "false");
             caret.style.transform = "rotate(0deg)";
             if (onSelect) onSelect(lang);
             showStartIfReady();
           });
           target.appendChild(a);
         }
         
         function toggleDropdown(currentMenu, currentCaret, currentButton, otherMenu, otherCaret, otherButton) {
           // Fecha o outro menu
           otherMenu.classList.add("hidden");
           otherCaret.style.transform = "rotate(0deg)";
           if (otherButton) otherButton.setAttribute("aria-expanded", "false");
         
           const isOpen = !currentMenu.classList.contains("hidden");
           currentCaret.style.transform = isOpen ? "rotate(0deg)" : "rotate(180deg)";
           currentMenu.classList.toggle("hidden");
           currentButton.setAttribute("aria-expanded", !isOpen);
         }
         
         nativeButton.addEventListener("click", (e) => {
           e.stopPropagation();
           toggleDropdown(nativeMenu, nativeCaret, nativeButton, learningMenu, learningCaret, learningButton);
         });
         
         learningButton.addEventListener("click", (e) => {
           if (learningButton.classList.contains("pointer-events-none")) return;
           e.stopPropagation();
           toggleDropdown(learningMenu, learningCaret, learningButton, nativeMenu, nativeCaret, nativeButton);
         });
         
         document.addEventListener("click", () => {
           nativeMenu.classList.add("hidden");
           learningMenu.classList.add("hidden");
           nativeCaret.style.transform = "rotate(0deg)";
           learningCaret.style.transform = "rotate(0deg)";
         });
         
         function loadOptions() {
           nativeOptions.innerHTML = "";
           learningOptions.innerHTML = "";
         
           languages.forEach(lang => {
             createOption(lang, nativeOptions, nativeSelected, nativeMenu, nativeButton, nativeCaret, (selectedNative) => {
               activateLearningButton();
               learningSelected.textContent = "Learning";
         
               learningOptions.innerHTML = "";
               languages
                 .filter(l => l !== selectedNative)
                 .forEach(filteredLang => {
                   createOption(filteredLang, learningOptions, learningSelected, learningMenu, learningButton, learningCaret);
                 });
             });
           });
         }
         
         loadOptions();
         
         startBtn.addEventListener("click", () => {
           const nativeLang = nativeSelected.textContent;
           const learningLang = learningSelected.textContent;
           const path = `languages/${nativeLang.toLowerCase()}/learning-${learningLang.toLowerCase()}/index.html`;
           window.location.href = path;
         });
      