let currentIndex = 0;
let audio = new Audio();
let isMuted = false;
let isRunning = false;

function renderCarousel({ vocabulario, fromLang, toLang }) {
  const carousel = document.getElementById("carousel");
  const playBtn = document.getElementById("playBtn");
  const playIcon = document.getElementById("playIcon");
  const muteOffBtn = document.getElementById("muteOffBtn");
  const muteOnBtn = document.getElementById("muteOnBtn");
  const prevBtn = document.getElementById("prevBtn");
  const nextBtn = document.getElementById("nextBtn");

  const data = vocabulario.map((item) => ({
    text1: item.text?.[toLang] || "[sem texto]",
    text2: item.text?.[fromLang] || "[sem tradução]",
    audio: item.audio?.[fromLang] || null,
  }));

  function setPlayIcon() {
    playIcon.innerHTML = `<path fill-rule="evenodd" d="M4.5 5.653c0-1.427 1.529-2.33 2.779-1.643l11.54 6.347c1.295.712 1.295 2.573 0 3.286L7.28 19.99c-1.25.687-2.779-.217-2.779-1.643V5.653Z" clip-rule="evenodd" />`;
  }

  function setPauseIcon() {
    playIcon.innerHTML = `<path fill-rule="evenodd" d="M5.25 4.5A.75.75 0 0 1 6 3.75h3a.75.75 0 0 1 .75.75v15a.75.75 0 0 1-.75.75H6a.75.75 0 0 1-.75-.75v-15Zm9 0a.75.75 0 0 1 .75-.75h3a.75.75 0 0 1 .75.75v15a.75.75 0 0 1-.75.75h-3a.75.75 0 0 1-.75-.75v-15Z" clip-rule="evenodd"/>`;
  }

  function toggleMuteButtons() {
    muteOnBtn.classList.toggle("hidden", isMuted);
    muteOffBtn.classList.toggle("hidden", !isMuted);
  }

  function clearAudio() {
  audio.pause();
  audio.currentTime = 0;
  audio.onended = null;
  isRunning = false;
}

  function updateCarousel() {
    const cards = carousel.children;
    if (cards[currentIndex]) {
      cards[currentIndex].scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
    }
  }
  

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function playAudioStep() {
  if (isRunning) {
    clearAudio();
    setPlayIcon();
    return;
  }

  isRunning = true;
  setPauseIcon();

  while (currentIndex < data.length && isRunning) {
    const current = data[currentIndex];
    const overlay = document.getElementById(`overlay-${currentIndex}`);

    if (!current.audio || !current.audio.endsWith(".mp3")) {
      if (overlay) overlay.classList.add("opacity-0");
      currentIndex++;
      updateCarousel();
      await sleep(500);
      continue;
    }

    // overlay.textContent = "LISTEN";
    // overlay.classList.remove("opacity-0", "animate-pulse");

    // Play first time
    audio.src = current.audio;
    audio.muted = isMuted;
    audio.currentTime = 0;
    await audio.play().catch(console.warn);

    await new Promise(resolve => {
      audio.onended = resolve;
    });

    // Show  REPEAT
    overlay.textContent = "REPEAT";
    overlay.classList.add("animate-pulse");

    await sleep(2000);

    // Play again
    audio.currentTime = 0;
    await audio.play().catch(console.warn);

    await new Promise(resolve => {
      audio.onended = resolve;
    });

    // Advance
    overlay.classList.remove("animate-pulse");
    overlay.classList.add("opacity-0");

    currentIndex++;
    updateCarousel();
    await sleep(400);
  }

  isRunning = false;
  setPlayIcon();
}


  function nextCard() {
    clearAudio();
    setPlayIcon();
    currentIndex = (currentIndex + 1) % data.length;
    updateCarousel();
  }

  function prevCard() {
    clearAudio();
    setPlayIcon();
    currentIndex = (currentIndex - 1 + data.length) % data.length;
    updateCarousel();
  }

  // Events
  muteOffBtn.addEventListener("click", () => {
    isMuted = false;
    audio.muted = false;
    toggleMuteButtons();
  });

  muteOnBtn.addEventListener("click", () => {
    isMuted = true;
    audio.muted = true;
    toggleMuteButtons();
  });

  playBtn.addEventListener("click", playAudioStep);
  nextBtn.addEventListener("click", nextCard);
  prevBtn.addEventListener("click", prevCard);

  // Render cards
  carousel.innerHTML = "";
  data.forEach((item, index) => {
    const card = document.createElement("div");
    card.className = "flex-shrink-0 w-full bg-white rounded-lg shadow-md p-6 text-center flex flex-col justify-between snap-center";
    card.innerHTML = `
      <div class="text-left text-md text-gray-500 mb-2">${index + 1}/${data.length}</div>
      <div class="relative mb-2 flex-grow flex flex-col justify-center">
        <div id="overlay-${index}" class="text-center text-extrabold text-slate-700 opacity-0"></div>
        <div id="text2-${index}" class="text-2xl font-semibold text-green-500 relative z-0">${item.text2}</div>
      </div>
      <div class="text-base text-md text-slate-700 mb-6">${item.text1}</div>
    `;
    carousel.appendChild(card);
  });

  updateCarousel();
  toggleMuteButtons();
  setPlayIcon();
}