function renderQuiz({
   quizData,
   containerIds,
   questionLang = 'indonesian',
   optionsLang = 'portuguese',
   // audioLang = ' ',
}) {
   const {
      wordId,
      optionsId,
      muteBtnId,
      resultId,
      finalScoreId,
      restartBtnId
   } = containerIds;

    // Acesso ao JSON aninhado
function getText(q) {
  return q.text?.[questionLang] || "[sem texto]";
}

function getOptions(q) {
  return q.options?.[optionsLang] || [];
}

function getAnswer(q) {
  return q.answer?.[optionsLang] || "";
}

function getAudio(q) {
  return q.audio?.[questionLang] || null;
}


   const wordEl = document.getElementById(wordId);
   const optionsEl = document.getElementById(optionsId);
   const muteBtn = document.getElementById(muteBtnId);
   const resultEl = document.getElementById(resultId);
   const finalScoreEl = document.getElementById(finalScoreId);
   const restartBtn = document.getElementById(restartBtnId);

   const iconSoundOn = `
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
      <path stroke-linecap="round" stroke-linejoin="round" d="M19.114 5.636a9 9 0 0 1 0 12.728M16.463 8.288a5.25 5.25 0 0 1 0 7.424M6.75 8.25l4.72-4.72a.75.75 0 0 1 1.28.53v15.88a.75.75 0 0 1-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.009 9.009 0 0 1 2.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75Z" />
    </svg>
  `;

   const iconSoundOff = `
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
      <path stroke-linecap="round" stroke-linejoin="round" d="M17.25 9.75 19.5 12m0 0 2.25 2.25M19.5 12l2.25-2.25M19.5 12l-2.25 2.25m-10.5-6 4.72-4.72a.75.75 0 0 1 1.28.53v15.88a.75.75 0 0 1-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.009 9.009 0 0 1 2.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75Z" />
    </svg>
  `;

   let current = 0;
   let score = 0;
   let wrongAnswers = [];
   let isMuted = false;
   let currentAudio = null;
   let hasInteracted = false;

   function stopCurrentAudio() {
      if (currentAudio) {
         currentAudio.pause();
         currentAudio.currentTime = 0;
         currentAudio = null;
      }
   }

   function playAudio(src) {
      stopCurrentAudio();
      if (!isMuted && src) {
         currentAudio = new Audio(src);
         currentAudio.play();
      }
   }

   function embaralharArray(array) {
      const copia = [...array];
      for (let i = copia.length - 1; i > 0; i--) {
         const j = Math.floor(Math.random() * (i + 1));
         [copia[i], copia[j]] = [copia[j], copia[i]];
      }
      return copia;
   }

   function showQuestion() {
      const q = quizData[current];
      const question = getText(q);
      const options = embaralharArray(getOptions(q));
      const correct = getAnswer(q);
      const audioSrc = getAudio(q);
     
      wordEl.textContent = question;
      optionsEl.innerHTML = "";
      resultEl.textContent = "";

      options.forEach(option => {
         const btn = document.createElement("button");
         btn.textContent = option;
         btn.className = "w-full px-20 md:px-32 py-2 border rounded-lg text-lg text-gray-500 dark:text-manetee hover:scale-105 transition";
         btn.onclick = () => handleAnswer(option, correct, question, btn);
         optionsEl.appendChild(btn);
      });

      if (hasInteracted) {
         playAudio(audioSrc);
      }
   }

   function handleAnswer(selected, correct, questionText, btn) {
      hasInteracted = true;
      [...optionsEl.children].forEach(b => b.disabled = true);

      if (selected === correct) {
         btn.classList.add("bg-green-500", "text-white");
         score++;
      } else {
         btn.classList.add("bg-red-500", "text-white");
         wrongAnswers.push({
            question: questionText,
            correct,
            selected
         });
      }

      setTimeout(() => {
         current++;
         if (current < quizData.length) {
            showQuestion();
         } else {
            showResults();
         }
      }, 1000);
   }

   function showResults() {
      wordEl.textContent = "";
      optionsEl.innerHTML = "";
      muteBtn.classList.add("hidden");

      finalScoreEl.classList.remove("hidden");
      finalScoreEl.classList.add("mt-6", "p-4", "rounded-lg", "flex", "flex-col", "items-center");
      
      const scoreText = `<p class="text-lg mb-2 dark:text-white">${score} - ${quizData.length}</p>`;

      // const wrongList = wrongAnswers.map(w => ` `).join("");

      // const wrongSection = ` <h3 class="font-semibold text-lg mb-4 dark:text-manatee">Wrong questions :(</h3>`;

      const successMessage = `<p class="text-green-600 font-bold tracking-wide uppercase">Congratulations :)</p>`;

      finalScoreEl.innerHTML = `
      <h2 class="text-2xl font-bold mb-2 dark:text-manatee">Your Score</h2>
      ${scoreText}
      ${wrongAnswers.length > 0 ? wrongSection : successMessage}
    `;

      restartBtn.classList.remove("hidden");
   }

   restartBtn.onclick = () => {
      current = 0;
      score = 0;
      wrongAnswers = [];
      hasInteracted = false;
      muteBtn.classList.remove("hidden");
      finalScoreEl.classList.add("hidden");
      restartBtn.classList.add("hidden");
      showQuestion();
   };

   muteBtn.innerHTML = iconSoundOn;
   muteBtn.onclick = () => {
      isMuted = !isMuted;
      muteBtn.innerHTML = isMuted ? iconSoundOff : iconSoundOn;
      stopCurrentAudio();
   };

   showQuestion();
}