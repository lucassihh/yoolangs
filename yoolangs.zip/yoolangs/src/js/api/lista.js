function renderLista({
  lista,
  containerId,
  fromLang,
}) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const frases = lista
    .map(item => item.text?.[fromLang])
    .filter(Boolean)
    .join(', ');

  container.textContent = frases;
}