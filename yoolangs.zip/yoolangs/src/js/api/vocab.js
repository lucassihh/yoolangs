function renderVocabulario({
  vocabulario,
  containerId,
  muteBtnId,
  fromLang = 'indonesian',
  toLang = 'portuguese',
}) {
  const container = document.getElementById(containerId);
  const muteBtn = document.getElementById(muteBtnId);
  let isMuted = false;
  let currentAudio = null;

  const iconSoundOn = `
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" 
         stroke-width="1.5" stroke="currentColor" class="size-6">
      <path stroke-linecap="round" stroke-linejoin="round" 
            d="M19.114 5.636a9 9 0 0 1 0 12.728M16.463 8.288a5.25 5.25 0 0 1 0 7.424M6.75 8.25l4.72-4.72a.75.75 0 0 1 1.28.53v15.88a.75.75 0 0 1-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.009 9.009 0 0 1 2.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75Z" />
    </svg>
  `;

  const iconSoundOff = `
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" 
         stroke-width="1.5" stroke="currentColor" class="size-6">
      <path stroke-linecap="round" stroke-linejoin="round" 
            d="M17.25 9.75 19.5 12m0 0 2.25 2.25M19.5 12l2.25-2.25M19.5 12l-2.25 2.25m-10.5-6 4.72-4.72a.75.75 0 0 1 1.28.53v15.88a.75.75 0 0 1-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.009 9.009 0 0 1 2.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75Z" />
    </svg>
  `;

  function stopCurrentAudio() {
    if (currentAudio) {
      currentAudio.pause();
      currentAudio.currentTime = 0;
      currentAudio = null;
    }
  }

  function playAudio(src) {
    stopCurrentAudio();
    if (!isMuted && src) {
      currentAudio = new Audio(src);
      currentAudio.play();
    }
  }

  function createVocabItem(item) {
    const fromText = item.text?.[fromLang] || '';
    const toText = item.text?.[toLang] || '';
    const audio = item.audio?.[fromLang] || null;
    const wrapper = document.createElement('div');

    wrapper.innerHTML = `
      <div class="flex space-x-2">
        <span class="inline-flex justify-center items-center w-6 h-6 rounded bg-green-500 text-white font-medium text-md">Q</span>
        <p class="text-green-500 text-lg font-semibold">${fromText}</p>
      </div>
      <div class="flex space-x-2">
        <span class="inline-flex justify-center items-center w-6 h-6 rounded bg-gray-200 text-gray-800 font-medium text-md">A</span>
        <p class="text-gray-800 text-base font-normal mb-4">${toText}</p>
      </div>
    `;

    const questionText = wrapper.querySelector('p.text-green-500');
    if (questionText && audio) {
      questionText.addEventListener('click', () => playAudio(audio));
    }

    return wrapper;
  }

  // Limpa o conteúdo atual
  container.innerHTML = '';

  // Adiciona os itens diretamente ao container
  vocabulario.forEach((item) => {
    container.appendChild(createVocabItem(item));
  });

  // Botão de mute
  if (muteBtn) {
    muteBtn.innerHTML = iconSoundOn;
    muteBtn.addEventListener('click', () => {
      isMuted = !isMuted;
      muteBtn.innerHTML = isMuted ? iconSoundOff : iconSoundOn;
      stopCurrentAudio();
    });
  }
}