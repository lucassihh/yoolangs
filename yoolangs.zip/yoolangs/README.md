# Dependências para usar o script TERMUX
$ pkg install inotify-tools rsync

# Copiar a pasta yok para o TERMUX 
$ cp -r /storage/emulated/0/htdocs/yoolangs ~/

# ( Opcional ) Copiar de volta
$ cp -r ~/yoolangs /storage/emulated/0/htdocs/